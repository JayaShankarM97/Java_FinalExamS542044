/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CastingTypes_Pb3;

/**
 *
 * @author JayaShankar Mangina
 */
public class AppleCompany extends FAANG{
    int companyRanking;
    
    @Override
    public void display(){
        System.out.println("Apple Incorporation");
    }
}
