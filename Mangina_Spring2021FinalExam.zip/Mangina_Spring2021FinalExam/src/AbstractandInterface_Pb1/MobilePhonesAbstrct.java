/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AbstractandInterface_Pb1;

/**
 *
 * @author JayaShankar Mangina
 */
public abstract class MobilePhonesAbstrct {
    
    public abstract void brandLogo();
    
    public void NameOfTheBrand(){
        System.out.println("Brand: Apple Incorporation");
    }
    
    public void PriceOfTheMobilePhone(){
        System.out.println("Price: 999.99 USD");
    }
}
